# Fertigungspaket Rev 2.4 — `2.final`

**Datum:** 1. August 2026  
**Projekt:** Soundplatine Waldlehrpfad / Kolping Alteglofsheim  
**KiCad:** `vogelstimmen_v2.4.*`

## Inhalt

| Datei / Ordner | Zweck |
|----------------|--------|
| `vogelstimmen_v2.4.kicad_sch` | Schaltplan (KiCad) |
| `vogelstimmen_v2.4.kicad_pcb` | Layout (KiCad) |
| `vogelstimmen_v2.4.kicad_pro` | Projekt |
| `vogelstimmen_v2.4-schematic.pdf` | Schaltplan PDF |
| `vogelstimmen_v2.4-pcb.pdf` | PCB-Lagen PDF |
| `Gerber/` | Gerber + Drill + Job |
| `vogelstimmen_v2.4-Gerber.zip` | **Upload JLCPCB / PCB-Haus** |
| `vogelstimmen_v2.4-bom.csv` | Stückliste aus KiCad |
| `JLCPCB_BOM.csv` | SMD-BOM mit LCSC (Bestückung) |
| `vogelstimmen_v2.4-cpl.csv` | CPL / Position (nur SMD) |
| `vogelstimmen_v2.4-all-pos.csv` | Alle Footprints inkl. THT |
| `docs/` | DRC/ERC, BOM-Check, Datenblätter |
| `footprints/` | Custom Footprints (Kopie) |

Gesamtpaket zusätzlich: `hardware/2.final.zip`

## JLCPCB — PCB only

1. `vogelstimmen_v2.4-Gerber.zip` hochladen  
2. 2-layer, 1,6 mm, HASL oder ENIG nach Wahl  
3. Bestückung optional: `JLCPCB_BOM.csv` + `vogelstimmen_v2.4-cpl.csv`

## Manuell (nicht JLCPCB-SMD)

- **U2** DY-SV17F — Sockel 2×9 Pin-Header / Modul stecken  
- **J5** Kübler `1.130.900.008`  
- **J3/J4** Phoenix MPT 0,5/8-2,54 (z. B. 1725711)  
- **J1/J2/J6** Phoenix MPT 0,5/2-2,54  

## Prüflauf (dieses Paket)

| Check | Ergebnis |
|-------|----------|
| DRC | 0 unverbunden; 1 Warnung U2 Footprint vs. Lib |
| ERC | 0 Fehler; 1 Warnung `SET_DRV` isolated label |
| LCSC SMD | alle Kernteile lagernd (Stand 01.08.2026) |

Details: `docs/bom_verfuegbarkeit.md`, `docs/DRC_v2.4_final.rpt`, `docs/ERC_v2.4_final.rpt`

## Design-Review vor Bestellung

Vor JLCPCB-Upload bitte Freigabe über die Projekt-Docs:

1. [`../../docs/reviewer_handoff.md`](../../docs/reviewer_handoff.md) — Einstieg Reviewer  
2. [`../../docs/review_checkliste_m04.md`](../../docs/review_checkliste_m04.md) — Signatur  
3. Cursor-Canvas **fertigung-readiness-v24** — Gate-Überblick  

Kopien der Checkliste/Handoff liegen auch unter `docs/` in diesem Paket (falls mitgegeben).
