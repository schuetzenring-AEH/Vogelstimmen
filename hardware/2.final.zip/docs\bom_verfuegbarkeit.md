# BOM-Verfügbarkeitsprüfung LCSC/JLCPCB

**Datum:** 1. August 2026  
**Status:** Erneut geprüft (Fertigungsstand `hardware/2.final`)

## Ergebnis: Alle SMD-Kernbauteile verfügbar

| Ref | Bauteil | LCSC # | Bestand (01.08.2026) | Preis (ca.) | Status |
|-----|---------|--------|----------------------|-------------|--------|
| Q5, Q1, **Q6** | SI2301CDS-T1-GE3 (P-FET, SOT-23) | C10487 | ~326k | ~$0,07 | OK |
| D11, D12, **D14** | BZX84C6V2 (Zener 6,2 V, SOT-23) | **C179522** | ~1 360 | ~$0,02 | OK |
| R7, R8, **R11** | 4,7 kΩ 0402 | Standard | >1M | <$0,01 | OK |
| Q2, Q3 | 2N7002LT1G (N-FET, SOT-23) | C16338 | ~463k | ~$0,04 | OK |
| U1 | TPS62163DSGR (Buck 5V, WSON-8) | C97534 | **~510** | ~$0,80 | OK — Reserve |
| D9 | SMAJ15A (TVS, SMA) | C113958 | ~52k | ~$0,04 | OK |
| D1–D8, D10, D13 | 1N4148WS (SOD-323) | C118873 | ~68k | ~$0,04 | OK |
| F1 | SMD1206-100C-24V (1A/24V) | C2760272 | ~14k | ~$0,08 | OK |
| L1 | 2,2µH TDK 1008 (VLS252010HBX) | C88527 | ~2 120 | ~$0,08 | OK |
| C1, C2 | 10µF/25V 0805 X7R | Standard | >100k | <$0,01 | OK |
| C3 | 22µF/10V 0805 X7R | Standard | >100k | <$0,01 | OK |
| R1, R2, R5 | 100kΩ 0402 | Standard | >1M | <$0,01 | OK |
| R3, R4, R9 | 10kΩ 0402 | Standard | >1M | <$0,01 | OK |
| R6 | **470kΩ** 0402 (Q5 Gate→GND) | Standard | >1M | <$0,01 | OK |
| R10 | 1kΩ 0402 | Standard | >1M | <$0,01 | OK |

**Geschätzter SMD-Materialpreis:** ~$2,60–3,00 (ohne Bestückung)

Fertigungs-BOM: `hardware/2.final/JLCPCB_BOM.csv` (LCSC ergänzt wo im Schaltplan-Feld leer).

## VGS-Zener D11/D12/D14

| | |
|--|--|
| Typ | BZX84C6V2, 6,2 V, 350 mW, SOT-23 |
| LCSC | [C179522](https://www.lcsc.com/product-detail/C179522.html) (Good-Ark) |
| Alternativen JLCPCB | C2832549, C5155258, C6136743 (Vishay) |
| Polarität | Kathode = FET-Source, Anode = FET-Gate |
| Serie-R | R7/R8/R11 = 4,7 kΩ → ~1 mA Clamp-Strom bei 12 V |

## Hinweise

### PTC-Spannung
Nicht C20800 (nur 6 V). Nur C2760272 (24 V).

### TPS62163
Bestand begrenzt (~510) — **+1 Reserve** mitbestellen.

### 2N7002
Latch-Logik Q2/Q3. Kaltstart-SET ist **Q6 (P-FET)**, kein N-Inverter (Ruhestrom).

## Nicht bei LCSC (manuell)

| Bauteil | Quelle | Status |
|---------|--------|--------|
| DY-SV17F | AliExpress / eBay | ~3–5 EUR |
| Kübler K07.90 | **1.130.900.008** (4,5 V DC / 10 Hz Typ 0) | an 5 V ok (E-CNT-01); Alt. 12 V: **1.130.900.012** |
| Phoenix MPT 0,5/8-2,54 (J3, J4) | z. B. 1725711 | 2× manuell |
| Phoenix MPT 0,5/2-2,54 (J1, J2, J6) | gleiche Serie, 2-pol | 3× manuell |
| Pin-Sockel 2×9 für U2 | Standard 2,54 mm | optional |

## Empfohlene LCSC-Bestell-Liste

| LCSC # | Bauteil | Menge |
|--------|---------|-------|
| C10487 | SI2301CDS P-FET | 3 (Q5, Q1, Q6) +1 |
| **C179522** | **BZX84C6V2 Zener 6,2 V** | **3 (D11, D12, D14)** +1 |
| C16338 | 2N7002LT1G | 2 (Q2, Q3) +1 |
| C97534 | TPS62163DSGR | 1 **+1** |
| C113958 | SMAJ15A | 1 +1 |
| C118873 | 1N4148WS | 10 +3 |
| C2760272 | PTC 1A/24V | 1 +1 |
| C88527 | 2,2µH TDK | 1 +1 |
| — | 10µF/25V 0805 | 2 +2 |
| — | 22µF/10V 0805 | 1 +1 |
| — | 100kΩ 0402 | 3 +3 |
| — | 10kΩ 0402 | 3 +3 |
| — | 470kΩ 0402 | 1 +1 |
| — | **4,7kΩ 0402** | **3 +2** |
| — | 1kΩ 0402 | 1 +1 |
