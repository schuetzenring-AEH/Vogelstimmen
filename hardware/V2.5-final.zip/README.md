# Fertigungspaket Rev 2.5 — `V2.5-final`

**Datum:** 3. August 2026  
**Projekt:** Soundplatine Waldlehrpfad · Kolping Alteglofsheim · Konrad Senn  
**KiCad:** 10.0.4 · Quelle: `vogelstimmen_v2.5.kicad_*` (Respin F-01…F-05 + GND-Vias)

## Freigabe-Stand

| Check | Ergebnis |
|-------|----------|
| **DRC** | **0 Fehler**, 0 unverbunden — 1 Warnung U2 Footprint-Lib (`DRC_v2.5_final.rpt`) |
| **ERC** | **0 Fehler** — 1 Warnung Label `SET_DRV` (`ERC_v2.5_final.rpt`) |
| **F-01…F-09** | Behoben / dispositioniert — `docs/adversarial_review_v25.md` |

## JLCPCB — Upload

| Datei | Zweck |
|-------|--------|
| **`vogelstimmen_v2.5-Gerber.zip`** | Gerber + Drill (Ordner `Gerber/`) |
| **`JLCPCB_BOM.csv`** | SMD-Bestückung (LCSC-Nummern) |
| **`vogelstimmen_v2.5-cpl.csv`** | Pick-and-Place (nur SMD Top) |

**Platinen-Parameter (empfohlen):** 2 Layer · 1,6 mm · HASL oder ENIG · Design-Regeln wie im Projekt (0,2 mm Clearance, Via 0,6/0,3 mm).

## Manuell bestücken (nicht JLCPCB-SMD)

| Ref | Teil |
|-----|------|
| **U2** | DY-SV17F (optional 2×9-Pin-Sockel) |
| **J5** | Kübler `1.130.900.008` |
| **J1, J2, J6** | Phoenix MPT 0,5/2-2,54 (×3) |
| **J3, J4** | Phoenix MPT 0,5/8-2,54 (×2, z. B. 1725711) |

## Paketinhalt

| Datei / Ordner | Inhalt |
|----------------|--------|
| `Gerber/` | Einzel-Gerber + `.drl` + `.gbrjob` |
| `vogelstimmen_v2.5-Gerber.zip` | Upload-Paket |
| `JLCPCB_BOM.csv` | LCSC-SMD-BOM |
| `vogelstimmen_v2.5-bom.csv` | KiCad-Voll-BOM (inkl. THT) |
| `vogelstimmen_v2.5-cpl.csv` | CPL Top SMD |
| `vogelstimmen_v2.5-all-pos.csv` | Alle Positionen |
| `vogelstimmen_v2.5-schematic.pdf` | Schaltplan-PDF |
| `vogelstimmen_v2.5-pcb.pdf` | Layout-PDF |
| `vogelstimmen_v2.5.kicad_sch/pcb/pro` | KiCad-Quellen (Stand Export) |
| `docs/` | DRC/ERC, Review, Schaltplan-Doku |

## Respin-Änderungen (gegenüber Pre-Respin-Baseline (Rev 2.4, archiviert))

| ID | Änderung |
|----|----------|
| F-01 | D15–D22 Serie U2↔IOx |
| F-02 | R5 = 0 Ω |
| F-03 | R13 + C4 BUSY-Blanking |
| F-04 | R12 = 10 Ω → 12V_LED |
| F-05 | SPK ≥ 0,4 mm (Haupt 0,8 mm) |
| Layout | +13 GND-Vias (Stitching U1/C1–C4) |

## IBN-Hinweise

- **USB:** nur Modul abgezogen oder Latch aus (F-09)  
- **Proto optional:** F-03 Oszi, F-04 LED-Strom, F-08 5 V unter Last  

Review: `docs/reviewer_handoff.md` · Checkliste: `docs/review_checkliste_m04.md`
